const ManageWebsite = () => {
  return <div>ManageWebsite</div>;
};

export default ManageWebsite;
